<?php
    session_start();
    if(isset($_SESSION['inadmin'])){
        
    }else{
        header('Location: index.php');
    }
?>



<div data-reflow-type="shopping-cart" data-reflow-success-url="/success.php" data-reflow-cancel-url="/cancel.php">oi</div>